CREATE TABLE Shepel_Molenda.DIM_CUSTOMER (
    CustomerID INT PRIMARY KEY,
    FirstName NVARCHAR(50),
    LastName NVARCHAR(50),
    TerritoryName NVARCHAR(50),
    CountryRegionCode NVARCHAR(3),
    GroupName NVARCHAR(50)
);

CREATE TABLE Shepel_Molenda.DIM_PRODUCT (
    ProductID INT PRIMARY KEY,
    Name NVARCHAR(50),
    ListPrice MONEY,
    Color NVARCHAR(15),
    SubCategoryName NVARCHAR(50),
    CategoryName NVARCHAR(50)
);

CREATE TABLE Shepel_Molenda.DIM_SALESPERSON (
    SalesPersonID INT PRIMARY KEY,
    FirstName NVARCHAR(50),
    LastName NVARCHAR(50),
    Title NVARCHAR(8), -- A courtesy title. For example, Mr. or Ms.
    Gender NCHAR(1),
    CountryRegionCode NVARCHAR(3),
    GroupName NVARCHAR(50), -- Name of the group to which the department belongs
    Age INT
);

-- Added SalesOrderDetailID to uniquely identify record
CREATE TABLE Shepel_Molenda.FACT_SALES (
    SalesOrderID INT,
    SalesOrderDetailID INT,
    ProductID INT,
    CustomerID INT,
    SalesPersonID INT,
    OrderDate INT,
    ShipDate INT,
    OrderQty SMALLINT,
    UnitPrice MONEY,
    UnitPriceDiscount MONEY,
    LineTotal NUMERIC(38, 6),
    PRIMARY KEY (SalesOrderID, SalesOrderDetailID)
);
