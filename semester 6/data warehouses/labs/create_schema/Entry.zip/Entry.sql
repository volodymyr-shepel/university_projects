SELECT * FROM Shepel_Molenda.DIM_TIME

SELECT * FROM Shepel_Molenda.FACT_SALES